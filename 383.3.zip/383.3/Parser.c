#include<stdio.h>
#include<string.h>

int main()
{
	FILE *fp;

	char ch,buff[1024],last_word[1024];
	last_word[0]='\0';

	int j=0,lineno=1, brace_flag=-1, brace_line,buff_flag=0;

	fp = fopen("tokens.txt", "r");

	while(!feof(fp))
	{
		if (buff_flag==1)
		{
			strcpy(last_word, buff);
			buff_flag=0;
			buff[0] = buff[1] = buff[2] = '\0';	
		}

		ch = fgetc(fp);
		buff[j++] = ch;
		
		if(ch == '>' && j != 0)
		{
			buff[j] = '\0';
			j=0;
			buff_flag=1;
		}
		
		
		if (ch == '\n')
		{
			lineno++;
			j--;
			
			if ((strcmp(last_word,"<terminator>") != 0) && brace_flag == 1)
			{
				if ((strcmp(last_word,"<curl_open>") != 0))
					printf("\nError %d: Expected ;",lineno-1);
			}
		}
		
		if (strcmp(buff,"<arith_op>") == 0)
		{	
			if (strcmp(last_word,"<arith_op>") == 0)
				printf("\nError %d: Invalid Operator",lineno);
		}
		
		else if ((strcmp(buff,"<id>") == 0) || (strcmp(buff,"<keyw>") == 0))
		{
			if (strcmp(last_word,"<num>") == 0)
				printf("\nError %d: Invalid Identifier",lineno);
		}
		
		else if ((strcmp(buff,"<curl_open>") == 0) && (brace_flag == 0 || brace_flag == -1))
			brace_flag = 1;
			
		else if ((strcmp(buff,"<curl_close>") == 0) && brace_flag == 1)
			brace_flag = 0;
		

	}
	if (brace_flag == 1)
		printf("\nError %d: } expected\n",lineno+1);
	else if (brace_flag == -1)
		printf("\nError %d: Invalid use of curly braces\n",brace_line);
	fclose(fp);
}
