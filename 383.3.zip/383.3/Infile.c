int abc
float b;
char 4c;
for(i=1;i<=4; i++) 
{
i++;
b=5++-6;

