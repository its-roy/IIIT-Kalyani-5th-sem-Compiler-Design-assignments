#include <stdio.h>
#include "parser.h"

int inorder(ASTnode_t **tpp);