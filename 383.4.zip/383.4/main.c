#include <stdio.h>
#include "parser.h"
#include "backend.h"

int main() {

    ASTnode_t *tpp;

    if(parser(&tpp)==1) {
        printf("Value: %d\n", inorder(&tpp));
    }
    else {
        printf("Syntax Error\n");
    }

    return 0;
}