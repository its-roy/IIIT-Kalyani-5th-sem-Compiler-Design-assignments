#include "backend.h"

int inorder(ASTnode_t **tpp) {

	if((*(*tpp)).type=='R') {
        printf(":");
        scanf("%d", &((*(*tpp)).val));
        return (*(*tpp)).val;
    }
    else if((*(*tpp)).type=='D') {
		 return (*(*tpp)).val;  
    }
    else {
    	if((*(*tpp)).op=='*') {
	        return (inorder(&((*(*tpp)).left))*inorder(&((*(*tpp)).right)));
	    }
	    else {
	        return (inorder(&((*(*tpp)).left))+inorder(&((*(*tpp)).right)));
	    }
    }
}
