#include "lex.h"

token_t token;

void getNextToken(void) {
    char c;
    
    c=getchar();

    if(c==' '||c=='\t') {
        getNextToken();
    }

    if(c=='\n' || c==EOF) {
        token.tokenClass=END;
    }
    else if(isdigit(c)) {
        token.tokenClass=NUM;
        ungetc(c, stdin);
        scanf("%d", &token.val);
    }
    else {
        token.tokenClass=c;
        token.val=c;
    }
}