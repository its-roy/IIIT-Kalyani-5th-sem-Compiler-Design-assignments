#include "lex.h"
#include "parser.h"
#include <stdlib.h>

ASTnode_t *generate_node() {
    ASTnode_t *node = (ASTnode_t *)malloc(sizeof(ASTnode_t));
    node->left = NULL;
    node->right = NULL;
    
    return node;
}

int parseExp(ASTnode_t **tpp) {

    getNextToken();

    switch(token.tokenClass) {

    	case NUM:
    		(*tpp) = generate_node();
	        (*(*tpp)).type = 'D';
	        (*(*tpp)).val = token.val;
    	break;

    	case 'r':
	    	(*tpp) = generate_node();
	        (*(*tpp)).type = 'R';
	        (*(*tpp)).val = token.val;
    	break;

    	case '(':
    		(*tpp) = generate_node();
	        (*(*tpp)).type = 'I';
	        int left = parseExp(&((*(*tpp)).left));
	        getNextToken();
	        if(token.tokenClass=='+') {
	            (*(*tpp)).op='+';
	        } 
	        else if (token.tokenClass=='*') {
	            (*(*tpp)).op='*';
	        }
	        else {
	            return 0;
	        }
	        int right = parseExp(&((*(*tpp)).right));
	        getNextToken();

	        if(left!=1 || right!=1 || token.tokenClass!=')') {
	            return 0;
	        }
    	break;

    	default:
    		return 0;
    	break;
    }
    return 1;
}

int parser(ASTnode_t **tpp) {
   	int res = parseExp(tpp);

   	getNextToken();
   	
   	if(token.tokenClass==END)
   		return res;

   	return 0;
}

